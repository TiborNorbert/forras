<?php
include 'kozos/header.php';
$sql="SELECT `id`,`varos`,`kep` FROM `varosok`;";
$result = $db->RunSQL($sql);
?>
<div class="row">
    <main>
        <article class="d-flex flex-wrap" >
            <?php while ($row = $result->fetch_assoc()) : ?>
                <div class="col-sm-12 col-md-6 col-lg-4 col-xl-3 my-3">
                    <a href="Location:megtekintes.php=<?php echo $row['id']?>">
                    <div class="card mb-3 text-center h-100 mx-2">
                        <img class='card-img-top w-50 mx-auto '  src="img/<?= $row['kep']; ?>"  alt="...">
                        <div class="card-body">
                            <h2 class="card-title"><?= $row['varos']; ?></h2>
                        </div>
                    </div>
                    </a>
                </div>
            <?php endwhile; ?>
        </article>
    </main>
</div>
<?php
include 'kozos/footer.php';
?>