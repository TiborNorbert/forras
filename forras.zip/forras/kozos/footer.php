<footer class="container-fluid">
    <h3>&COPY; mekk elek-2022.</h3>
</footer>
</body>

</html>