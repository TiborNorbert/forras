<?php
include 'kozos/database.php';
$db= new Database();
session_start();
?>
<!DOCTYPE html>
<html lang="hu">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="kozos/bootstrap-icons.css" />
    <link rel="stylesheet" href="kozos/bootstrap.min.css" />
    <link rel="stylesheet" href="kozos/style.css" />
    <title>Városok</title>
</head>

<body>
    <div class="row">
        <header class="container-fluid">
            <div col-12>
                <img class="w-100" src="img/fejlec.png" alt="fejlec" />
            </div>
        <div class="container-fluid">
        <nav class="navbar navbar-light">
            <a class="navbar-brand">Eurázsiai városok</a>
            <form class="form-inline">
                <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
                <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
            </form>
        </nav>
        </header>
        </div>