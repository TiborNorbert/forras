<?php
include 'kozos/header.php';
?>
<?php
include 'kozos/footer.php';
?>